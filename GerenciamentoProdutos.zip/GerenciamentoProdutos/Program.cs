//melissa escarmeloto guedes cb3030296 e francielle santos freitas cb3032027

using System.Globalization;
using GerenciamentoProdutos.Data;
using GerenciamentoProdutos.Models;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    if (!db.Produtos.Any())
    {
        db.Produtos.AddRange(
            new Produto { Nome = "Teclado Mecânico", Descricao = "Teclado mecânico ABNT2 com iluminação RGB.", Preco = 249.90m, Estoque = 15 },
            new Produto { Nome = "Mouse Sem Fio", Descricao = "Mouse óptico sem fio com 1600 DPI.", Preco = 79.90m, Estoque = 40 },
            new Produto { Nome = "Monitor 24 polegadas", Descricao = "Monitor Full HD com painel IPS.", Preco = 899.00m, Estoque = 8 }
        );
        db.SaveChanges();
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Produtos/Index");
}

var cultura = new CultureInfo("pt-BR");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(cultura),
    SupportedCultures = new List<CultureInfo> { cultura },
    SupportedUICultures = new List<CultureInfo> { cultura }
});

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Produtos}/{action=Index}/{id?}");

app.Run();
