//melissa escarmeloto guedes cb3030296 e francielle santos freitas cb3032027


using GerenciamentoProdutos.Models;
using Microsoft.EntityFrameworkCore;

namespace GerenciamentoProdutos.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Produto> Produtos => Set<Produto>();
}
