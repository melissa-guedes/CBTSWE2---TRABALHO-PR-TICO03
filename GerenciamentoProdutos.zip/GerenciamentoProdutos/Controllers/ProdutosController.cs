//melissa escarmeloto guedes cb3030296 e francielle santos freitas cb3032027


using GerenciamentoProdutos.Data;
using GerenciamentoProdutos.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GerenciamentoProdutos.Controllers;

public class ProdutosController : Controller
{
    private readonly AppDbContext _context;

    public ProdutosController(AppDbContext context)
    {
        _context = context;
    }

    // GET: /Produtos  (página inicial - lista de produtos, com busca por nome)
    public async Task<IActionResult> Index(string? busca)
    {
        var consulta = _context.Produtos.AsQueryable();

        if (!string.IsNullOrWhiteSpace(busca))
        {
            consulta = consulta.Where(p => p.Nome.Contains(busca));
        }

        ViewData["Busca"] = busca;
        return View(await consulta.OrderBy(p => p.Nome).ToListAsync());
    }

    // GET: /Produtos/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var produto = await _context.Produtos.FirstOrDefaultAsync(p => p.Id == id);
        if (produto == null) return NotFound();

        return View(produto);
    }

    // GET: /Produtos/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: /Produtos/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Nome,Descricao,Preco,Estoque")] Produto produto)
    {
        if (!ModelState.IsValid) return View(produto);

        _context.Add(produto);
        await _context.SaveChangesAsync();
        TempData["Mensagem"] = "Produto cadastrado com sucesso!";
        return RedirectToAction(nameof(Index));
    }

    // GET: /Produtos/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();

        var produto = await _context.Produtos.FindAsync(id);
        if (produto == null) return NotFound();

        return View(produto);
    }

    // POST: /Produtos/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Nome,Descricao,Preco,Estoque")] Produto produto)
    {
        if (id != produto.Id) return NotFound();

        if (!ModelState.IsValid) return View(produto);

        try
        {
            _context.Update(produto);
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!await _context.Produtos.AnyAsync(p => p.Id == id)) return NotFound();
            throw;
        }

        TempData["Mensagem"] = "Produto atualizado com sucesso!";
        return RedirectToAction(nameof(Index));
    }

    // GET: /Produtos/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();

        var produto = await _context.Produtos.FirstOrDefaultAsync(p => p.Id == id);
        if (produto == null) return NotFound();

        return View(produto);
    }

    // POST: /Produtos/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var produto = await _context.Produtos.FindAsync(id);
        if (produto != null)
        {
            _context.Produtos.Remove(produto);
            await _context.SaveChangesAsync();
            TempData["Mensagem"] = "Produto excluído com sucesso!";
        }

        return RedirectToAction(nameof(Index));
    }
}
